﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace HomeWork11.Controllers
{
    [Route("[controller]")]
    public class SomeController : Controller
    {
        [HttpGet]
        [Route("[action]/{id}")]
        public IActionResult ReturnById([FromRoute] int id)
        {
            string str = string.Empty;
            if (id == 1)
            {
                str = "Ви ввели правильне значення!";
            }
            else
            {
                str = "Введено некоректне значення!";
            }
            return Ok(str);
        }
        [HttpGet]
        [Route("[action]")]
        public IActionResult ReturnCollection([FromBody] Car[] cars)
        {
            var str = string.Empty;
            foreach (var car in cars)
            {
                str += car.ToString();
            }
            return new ContentResult { Content = str };
        }
        [HttpPost]
        [Route("[action]")]
        public IActionResult AddCar([FromQuery] Car car)
        {
            string carInfo = $"Manufacturer: {car.Manufacturer}, MaxSpeed: {car.MaxSpeed}, Price: {car.Price}.";
            return Content(carInfo);
        }
        [HttpDelete]
        [Route("[action]")]
        public IActionResult DeleteAction([FromHeader] double speed)
        {
            List<Car> cars = new List<Car>
            {
                new Car {Manufacturer = "Ferrari", Price = 100000, MaxSpeed = 350},
                new Car {Manufacturer = "Opel", Price = 20000, MaxSpeed = 200},
                new Car {Manufacturer = "Bugatti", Price = 1000000, MaxSpeed = 400}
            };
            string carInfo = "Before deleting:\n";
            foreach (var car in cars)
            {
                carInfo += car.ToString();
            }
            int k = -1;
            foreach (var car in cars)
            {
                if (car.MaxSpeed == speed)
                    k = cars.IndexOf(car);
            }
            if (k != -1)
                cars.RemoveAt(k);
            carInfo += "\nAfter deleting:\n";
            foreach (var car in cars)
            {
                carInfo += car.ToString();
            }
            return Content(carInfo);
        }
        [HttpPut]
        [Route("[action]")]
        public IActionResult PutAction([FromHeader] int price = 50000)
        {
            Car car = new Car { Manufacturer = "Jaguar", MaxSpeed = 300, Price = 200000 };
            string carInfo = $"Before changing:\nManufacturer: {car.Manufacturer}, MaxSpeed: {car.MaxSpeed}, Price: {car.Price}.\n";
            car.Price = price;
            carInfo += $"After changing:\nManufacturer: {car.Manufacturer}, MaxSpeed: {car.MaxSpeed}, Price: {car.Price}.\n";
            return Content(carInfo);
        }
    }
    public class Car
    {
        public int Price { get; set; }
        public string Manufacturer { get; set; }
        public double MaxSpeed { get; set; }
        public override string ToString()
        {
            return String.Format($"{Manufacturer} costs {Price} euros and can reach top speed of {MaxSpeed} km/hour\n");
        }
    }
}
